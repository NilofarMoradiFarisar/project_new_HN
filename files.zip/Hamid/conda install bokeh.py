i = 1
i =i + 1
score = 5 
score += 1
# a*a + b*b  
# c = (a+b)*(a-b)